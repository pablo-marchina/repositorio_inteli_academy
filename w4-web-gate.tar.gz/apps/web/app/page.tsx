import Link from "next/link";
import { EventCard } from "../components/EventCard";
import { NaturalSearch } from "../components/NaturalSearch";
import { ApiUnavailableError, searchHackathons } from "../lib/api";
import type { HackathonListItem } from "../lib/types";

export default async function Home() {
  let events: HackathonListItem[] = []; let outage = false;
  try { const q = new URLSearchParams({ sort: "start", limit: "6" }); events = (await searchHackathons(q)).items; } catch (e) { if (e instanceof ApiUnavailableError) outage = true; else throw e; }
  return <main>
    <section className="hero"><div><p className="eyebrow">Global opportunity intelligence</p><h1>Find the hackathon worth building for.</h1><p className="lead">One canonical event record assembled from official pages, organizers, platforms and the open web — with freshness, quality and source evidence attached.</p><p><Link className="button" href="/search">Explore hackathons</Link></p></div><div className="hero-panel"><p className="eyebrow">What is different</p><h2>Not a link directory.</h2><p className="muted">We reconcile duplicate listings, preserve editions, expose source evidence and track meaningful changes over time.</p></div></section>
    <NaturalSearch />
    <section><div className="results-header"><div><p className="eyebrow">Canonical opportunities</p><h2>Upcoming & active</h2></div><Link href="/search">View all →</Link></div>
      {outage ? <div className="outage"><strong>Data service unavailable.</strong><p className="muted">The event index could not be reached. This is different from a zero-result search.</p></div> : events.length ? <div className="event-grid">{events.map((event) => <EventCard event={event} key={event.id} />)}</div> : <div className="empty-state">No active events currently match the default discovery window.</div>}
    </section>
  </main>;
}
