import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getSeries } from "../../../lib/api";
import type { HackathonListItem } from "../../../lib/types";
type Series={id:string;slug:string;name:string;official_url?:string|null;editions:HackathonListItem[]};
export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{const{slug}=await params;try{const s=await getSeries<Series>(slug);return{title:s.name,description:`Chronological editions of ${s.name}`,alternates:{canonical:`/series/${s.slug}`}}}catch{return{title:"Event series"}}}
const d=(v?:string|null)=>v?new Intl.DateTimeFormat("en",{dateStyle:"medium"}).format(new Date(v)):"Date TBA";
export default async function SeriesPage({params}:{params:Promise<{slug:string}>}){const{slug}=await params;let s:Series;try{s=await getSeries<Series>(slug)}catch{notFound()}return <main><p className="eyebrow">Recurring event series</p><h1>{s.name}</h1>{s.official_url?<p><a href={s.official_url}>Official series site ↗</a></p>:null}<section className="section"><h2>Editions</h2><div className="series-list">{s.editions.map((e)=><div className="series-row" key={e.id}><span>{d(e.start_at)}</span><div><strong><Link href={`/hackathons/${e.slug}`}>{e.name}</Link></strong><div className="muted">{e.status.replaceAll("_"," ")} · {e.format.replaceAll("_"," ")}</div></div><span>{e.country_code??"Global / online"}</span></div>)}</div></section></main>}
