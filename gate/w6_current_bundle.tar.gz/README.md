# Hackathon Intelligence Platform

Production-oriented monorepo for discovering, ingesting, reconciling, searching, and recommending hackathons globally.

## Repository layout

- `apps/api` — FastAPI service.
- `apps/worker` — background worker service.
- `apps/web` — Next.js frontend.
- `packages/shared` — shared Python contracts/utilities.
- `db` — Alembic configuration, migrations, and PostgreSQL physical schema.
- `infra/docker` — local infrastructure.
- `scripts` — verification and developer automation.

## Local development

1. Copy `.env.example` to `.env`.
2. Start infrastructure with `docker compose -f infra/docker/compose.yml up -d`.
3. Create a Python 3.11+ virtualenv and install `.[dev]`.
4. Run migrations: `alembic -c db/alembic.ini upgrade head`.
5. Run API: `uvicorn hackathon_api.main:app --reload --app-dir apps/api/src`.
6. Run worker: `celery -A hackathon_worker.app:celery_app worker --loglevel=INFO`.
7. In `apps/web`, run `npm ci && npm run dev`.

## Quality gates

`make verify` runs Python formatting/lint/type/tests and repository-level static verification.

> Runtime PostgreSQL/Docker verification requires Docker and PostgreSQL client/runtime to be installed on the host.

## Current execution baseline

Implementation has started across W0–W6. See `docs/IMPLEMENTATION_STATUS.md` and `docs/execution/` for acceptance status by wave. `Done` means the relevant acceptance behavior has been verified; `Blocked` means an external runtime/capacity prerequisite is unavailable; `Review` is reserved for implemented work still awaiting an acceptance gate.

Current local verification baseline:

```text
92 pytest tests passing
PostgreSQL 16 real migration cycle: upgrade → downgrade → upgrade passing
PostgreSQL schema baseline: 71 tables, 5 required extensions
source SDK: 4 authorized live API adapters registered
unified eval runner: passing
editable Python package install: passing
```

The PostgreSQL migration round-trip gate has been validated on a real PostgreSQL 16 database. W1 has four authorized live connectors and the Python runner produced complete `crawl_runs → fetch_attempts → raw_documents → source_event_refs` chains for all four sources, totaling 605 source-event refs. W2 replayed those 605 refs end-to-end into 7,346 field observations, 251 hackathon-like candidates, and 250 active canonical hackathons. W2 is now fully closed: 25 recurring event series / 60 editions, a 470-pair dedup golden set with 240/240 correct AUTO_MERGE decisions and a 98.4246% Wilson lower bound, plus real transactional split/undo/re-merge verification on Sierra Hacks. W3 is now fully closed: 10-language versioned query generation, policy-aware search/frontier ingestion, robots/sitemap/RSS discovery, bounded related-link exploration, a versioned hackathon-like classifier, and an 80-case / 10-language / 76-domain golden set. The live open-web gate passed in GitHub Actions run 35884553285 with 4/4 policy decisions, 2 fail-closed hosts, 2 fetched hackathon-like pages, 2 related links and 2 sitemap candidates. The exact W3 persistence migration was also exercised on PostgreSQL 17 with query attribution, DISCOVERY_ONLY provenance, idempotent frontier upsert and false-positive review routing. W4 is fully closed with its API/search/frontend gates, and W5 Recommendation + Alerts is now fully closed with 6/6 issues / 42/42 points. PostgreSQL 17 verified preference/recommendation/saved-search/alert idempotency, GitHub Actions run 35905927315 passed Next.js production build and route smokes, and an SMTP message was delivered and inspected through Mailpit. The next implementation wave is W6 Admin + evals + release hardening.
