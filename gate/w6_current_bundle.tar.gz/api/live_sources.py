from __future__ import annotations

import asyncio
import json
import sys
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[1]
for path in [
    ROOT / "packages/source_sdk/src",
    ROOT / "packages/shared/src",
]:
    sys.path.insert(0, str(path))

from hackathon_sources.factory import build_adapter, live_adapter_keys
from hackathon_sources.fetcher import FetchEngine
from hackathon_sources.registry import load_source_definitions
from hackathon_sources.runner import run_source_once


async def _run(selected: set[str], max_pages: int) -> list[dict[str, object]]:
    definitions = load_source_definitions(ROOT / "db/seeds/sources_v0_1.json")
    definitions = [definition for definition in definitions if definition.key in selected]
    outputs: list[dict[str, object]] = []
    async with FetchEngine() as fetcher:
        for definition in definitions:
            result = await run_source_once(build_adapter(definition), fetcher, max_pages=max_pages)
            outputs.append({
                "source": result.source_key,
                "fetched_pages": result.fetched_pages,
                "records": len(result.records),
                "discovered_links": result.discovered_links,
                "errors": result.errors,
                "sample": [
                    {
                        "source_event_id": record.source_event_id,
                        "name": record.name,
                        "source_url": str(record.source_url),
                        "official_url": str(record.official_url) if record.official_url else None,
                        "starts_at_raw": record.starts_at_raw,
                        "ends_at_raw": record.ends_at_raw,
                        "format_raw": record.format_raw,
                        "city": record.city,
                        "state_region": record.state_region,
                        "country": record.country,
                        "country_code": record.country_code,
                    }
                    for record in result.records[:5]
                ],
            })
    return outputs


class handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        requested = set(query.get("source", []))
        selected = requested or set(live_adapter_keys())
        allowed = set(live_adapter_keys())
        selected &= allowed
        try:
            max_pages = max(1, min(int(query.get("max_pages", ["2"])[0]), 5))
        except ValueError:
            max_pages = 2

        if not selected:
            self._json(400, {"error": "no valid source selected", "allowed": sorted(allowed)})
            return
        try:
            result = asyncio.run(_run(selected, max_pages))
            self._json(200, {"ok": True, "results": result})
        except Exception as exc:
            self._json(500, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})

    def _json(self, status: int, payload: object) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("cache-control", "no-store")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
