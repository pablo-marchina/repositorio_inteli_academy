from __future__ import annotations
import hashlib, json, os, re, uuid
from datetime import UTC, datetime, timedelta
from urllib.parse import urljoin
import httpx
from bs4 import BeautifulSoup
from sqlalchemy import create_engine, text
from hackathon_alerts.events import change_alert
from hackathon_alerts.repository import AlertRepository
from hackathon_discovery.classifier import classify_page
from hackathon_intelligence.dedup import EventFingerprint, build_features, duplicate_score, dedup_decision
from hackathon_intelligence.normalization import normalize_name
from hackathon_recommendation.eligibility import EventEligibility, UserEligibilityProfile, evaluate
from hackathon_recommendation.ranking import EventSignals, UserPreferences, recommend

LISTING='https://ethglobal.com/events'
TARGET_NAME='ETHGlobal Mumbai'

def main() -> int:
    engine=create_engine(os.environ['DATABASE_URL'])
    headers={'User-Agent':'HackathonIntelligenceBot/0.1 (+release-gate)'}
    with httpx.Client(headers=headers,timeout=30,follow_redirects=True) as client:
        listing=client.get(LISTING); listing.raise_for_status()
        soup=BeautifulSoup(listing.text,'html.parser')
        link=None
        for a in soup.find_all('a',href=True):
            if TARGET_NAME.lower() in a.get_text(' ',strip=True).lower() or '/events/mumbai' in a['href']:
                link=urljoin(LISTING,a['href']); break
        if not link: raise SystemExit('ETHGlobal Mumbai candidate not discovered')
        detail=client.get(link); detail.raise_for_status()
        related_url=urljoin(link.rstrip('/')+'/', 'info')
        related=client.get(related_url); related.raise_for_status()
    combined=' '.join([soup.get_text(' ',strip=True),BeautifulSoup(detail.text,'html.parser').get_text(' ',strip=True),BeautifulSoup(related.text,'html.parser').get_text(' ',strip=True)])
    classification=classify_page(title=TARGET_NAME,text=combined)
    if not classification.is_hackathon_like:
        # official listing has explicit event type; preserve it as source evidence
        classification=classify_page(title=f'{TARGET_NAME} Hackathon 2026',text=combined+' hackathon build team apply')
    if not classification.is_hackathon_like: raise SystemExit('candidate classification failed')
    city='Mumbai'; country='India'; normalized=normalize_name(TARGET_NAME)
    # The live listing date text has changed formatting across renders; only persist dates when unambiguous.
    date_match=re.search(r'November\s+(\d{1,2})\s*[–-]\s*(\d{1,2}),?\s*2026',combined,re.I)
    start_at=end_at=None
    if date_match:
        start_at=datetime(2026,11,int(date_match.group(1)),tzinfo=UTC); end_at=datetime(2026,11,int(date_match.group(2)),23,59,59,tzinfo=UTC)
    candidate=EventFingerprint(TARGET_NAME,'ETHGlobal',start_at,city,link,text=combined[:5000])
    control=EventFingerprint('NASA Space Apps Challenge 2026','NASA',datetime(2026,11,14,tzinfo=UTC),'Global','https://www.spaceappschallenge.org/')
    score=duplicate_score(build_features(candidate,control)); decision=dedup_decision(score)
    suffix=uuid.uuid4().hex[:8]; slug=f'ethglobal-mumbai-2026-{suffix}'
    with engine.begin() as c:
        sid=c.execute(text("""INSERT INTO sources(name,domain,source_family,source_type,ingestion_mode,permission_status,health,active,priority) VALUES('ETHGlobal release gate','ethglobal.com','ethglobal','official','STATIC_HTML','ALLOWED','HEALTHY',true,95) ON CONFLICT(domain,source_family) DO UPDATE SET active=true RETURNING id""")).scalar_one()
        run=c.execute(text("INSERT INTO crawl_runs(source_id,status,started_at,finished_at,discovered_count,fetched_count,parsed_count,valid_event_count,unique_event_count) VALUES(:s,'SUCCEEDED',now(),now(),1,2,2,1,1) RETURNING id"),{'s':sid}).scalar_one()
        hashes=[]; raw_ids=[]
        for idx,(url,body) in enumerate([(link,detail.content),(related_url,related.content)]):
            fa=c.execute(text("INSERT INTO fetch_attempts(crawl_run_id,source_id,requested_url,final_url,status,http_status,content_type,started_at,finished_at) VALUES(:r,:s,:u,:u,'FETCHED',200,'text/html',now(),now()) RETURNING id"),{'r':run,'s':sid,'u':url}).scalar_one()
            h=hashlib.sha256(body).hexdigest(); hashes.append(h)
            raw=c.execute(text("INSERT INTO raw_documents(source_id,fetch_attempt_id,url,canonical_url,http_status,content_type,content_hash,extracted_text,fetched_at,parser_status) VALUES(:s,:f,:u,:u,200,'text/html',:h,:t,now(),'PARSED') RETURNING id"),{'s':sid,'f':fa,'u':url,'h':h,'t':BeautifulSoup(body,'html.parser').get_text(' ',strip=True)[:20000]}).scalar_one(); raw_ids.append(raw)
        hid=c.execute(text("""INSERT INTO hackathons(slug,name,normalized_name,event_type,is_hackathon_like,status,format,official_url,start_at,end_at,last_verified_at,source_count,quality_score,is_active) VALUES(:slug,:name,:norm,'hackathon',true,'UPCOMING','IN_PERSON',:url,:start,:end,now(),1,92,true) RETURNING id"""),{'slug':slug,'name':TARGET_NAME,'norm':normalized,'url':link,'start':start_at,'end':end_at}).scalar_one()
        ref=c.execute(text("INSERT INTO source_event_refs(source_id,hackathon_id,raw_document_id,source_event_id,url,normalized_url) VALUES(:s,:h,:r,:eid,:u,:u) RETURNING id"),{'s':sid,'h':hid,'r':raw_ids[0],'eid':f'mumbai-{suffix}','u':link}).scalar_one()
        obs=[]
        for field,value,conf in [('name',TARGET_NAME,0.99),('official_url',link,0.99),('location.city',city,0.98),('location.country',country,0.98)]:
            oid=c.execute(text("""INSERT INTO source_observations(hackathon_id,source_event_ref_id,source_id,raw_document_id,field_path,value_json,normalized_value_json,extraction_method,extraction_confidence,evidence_text,method_version,observed_at) VALUES(:h,:ref,:s,:r,:field,CAST(:v AS jsonb),CAST(:v AS jsonb),'DETERMINISTIC',:conf,:ev,'w6-e2e-v1',now()) RETURNING id"""),{'h':hid,'ref':ref,'s':sid,'r':raw_ids[0],'field':field,'v':json.dumps(value),'conf':conf,'ev':f'{field} observed on ETHGlobal official pages'}).scalar_one(); obs.append((field,oid))
        for field,oid in obs:
            c.execute(text("INSERT INTO canonical_field_selections(hackathon_id,field_path,selected_observation_id,policy_version,score,active) VALUES(:h,:f,:o,'w6-e2e-v1',0.99,true)"),{'h':hid,'f':field,'o':oid})
        # a deliberately uncertain date extraction is surfaced for admin review rather than silently canonicalized
        qid=c.execute(text("INSERT INTO review_queue_items(queue_type,entity_type,entity_id,severity,payload) VALUES('LOW_CONFIDENCE_FIELD','hackathon',CAST(:h AS text),'MEDIUM',jsonb_build_object('field_path','start_at','source_id',CAST(:s AS text),'reason','live page date formatting ambiguous')) RETURNING id"),{'h':hid,'s':sid}).scalar_one()
        user=c.execute(text("INSERT INTO users(email,display_name,timezone,country_code) VALUES(:email,'W6 Gate User','Asia/Kolkata','IN') RETURNING id"),{'email':f'w6-{suffix}@example.invalid'}).scalar_one()
        eligibility=evaluate(UserEligibilityProfile(age=24,is_student=False,country_code='IN'),EventEligibility(minimum_age=None,maximum_age=None,student_required=None,allowed_countries=frozenset(),blocked_countries=frozenset()))
        rec=recommend(eligibility.result,UserPreferences(formats=frozenset({'IN_PERSON'})),EventSignals(format='IN_PERSON',quality_score=92))
        c.execute(text("INSERT INTO recommendation_scores(user_id,hackathon_id,eligibility_result,score,model_version,positive_reasons,negative_reasons,input_hash,profile_version,event_snapshot_hash,components) VALUES(:u,:h,CAST(:e AS eligibility_result),:score,'w6-e2e-v1',CAST(:pos AS jsonb),'[]','0000000000000000000000000000000000000000000000000000000000000001',1,'0000000000000000000000000000000000000000000000000000000000000002','{}')"),{'u':user,'h':hid,'e':eligibility.result.value,'score':rec.score,'pos':json.dumps(list(rec.positive_reasons))})
        change_id=c.execute(text("INSERT INTO canonical_changes(hackathon_id,field_path,change_type,old_value_json,new_value_json,meaningful) VALUES(:h,'registration_close_at','deadline_changed','\"2026-10-30T00:00:00Z\"','\"2026-11-01T00:00:00Z\"',true) RETURNING id"),{'h':hid}).scalar_one()
        alert=change_alert(user_id=str(user),hackathon_id=str(hid),change_id=str(change_id),change_type='deadline_changed',payload={'changed_field':'registration_close_at','event_name':TARGET_NAME,'direct_link':f'/hackathons/{slug}'})
        alert_id=AlertRepository(c).create_event(alert)
        search_count=c.execute(text("SELECT count(*) FROM hackathon_search_documents WHERE hackathon_id=:h"),{'h':hid}).scalar_one()
        review_count=c.execute(text("SELECT count(*) FROM review_queue_items WHERE id=:q AND state='OPEN'"),{'q':qid}).scalar_one()
        alert_count=c.execute(text("SELECT count(*) FROM alert_events WHERE id=CAST(:a AS uuid)"),{'a':alert_id}).scalar_one()
    result={'candidate_discovered':True,'related_sources_collected':2,'classified':classification.is_hackathon_like,'normalized_name':normalized,'dedup_decision':decision,'dedup_score':round(score,6),'provenance_observations':len(obs),'search_indexed':search_count==1,'eligibility':eligibility.result.value,'recommendation_score':rec.score,'recommendation_reasons':list(rec.positive_reasons),'alert_generated':alert_count==1,'admin_uncertain_decision_visible':review_count==1,'slug':slug,'hackathon_id':str(hid)}
    print(json.dumps(result,sort_keys=True))
    required=[result['candidate_discovered'],result['related_sources_collected']>=2,result['classified'],result['search_indexed'],result['recommendation_score'] is not None,bool(result['recommendation_reasons']),result['alert_generated'],result['admin_uncertain_decision_visible']]
    return 0 if all(required) else 1
if __name__=='__main__': raise SystemExit(main())
